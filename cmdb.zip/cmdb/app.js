var fs = require('fs');
var csv = require('fast-csv');
const pool = require('./pgdb');

pool.connect(function(err){
    if(err)
    {
        console.log(err);
    }
});

let counter = 1; 
let NoRecord =1;
// let header = [];
// let data = [];
//var csvStream = fs.readFileSync('csv/cmdb_data.csv', { encoding : 'utf8'})
let csvStream = csv.parseFile(".\\csv\\cmdb_data.csv", { headers: true })
    .on("data", function(record){
        csvStream.pause();
       
        if(counter <= NoRecord)
        {
            let c_name = record.c_name;
            let active = record.active;
            let hostname = record.hostname;
            let systemenvironment = record.systemenvironment;
            let discovered_location = record.discovered_location;
            let all_ip_addresses = record.all_ip_addresses;
            let primary_support_group = record.primary_support_group;
            let application_owning_group = record.application_owning_group;
            let tss_manager = record.tss_manager;
            let server_owner = record.server_owner;
            let bu_business_unit = record.bu_business_unit;
            let br_producttier1 = record.br_producttier1;
            let br_producttier2 = record.br_producttier2;
            let br_producttier3 = record.br_producttier3;
            let os_model = record.os_model;
            let os_type = record.os_type;
            let asset_instance_id = record.asset_instance_id;
            
            const qry = "INSERT INTO cmdb_Data(c_name, active, hostname, systemenvironment, discovered_location, all_ip_addresses, primary_support_group, application_owning_group, tss_manager, server_owner, bu_business_unit, br_producttier1, br_producttier2, br_producttier3, os_model, os_type, asset_instance_id) \
            VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)";
            console.log("qry is good");
            const value = [c_name, active, hostname, systemenvironment, discovered_location, all_ip_addresses, primary_support_group, application_owning_group, tss_manager, server_owner, bu_business_unit, br_producttier1, br_producttier2, br_producttier3, os_model, os_type, asset_instance_id];
            pool.query(qry, value, function(err, result){
                if(err)
                {
                    console.log(err);
                }
           });
           console.log("Total Records::::::", NoRecord);
            NoRecord ++;
            ++counter;
        }

        csvStream.resume();

    }).on("end", function(){
        console.log("CMDB Data successfully inserted into database!");
    }).on("error", function(err){
        console.log(err);
    });