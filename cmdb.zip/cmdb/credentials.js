
var credentials = {
    username: "postgres",
    password: "esp123",
    server: "localhost",
    database: "postgres",
    port: 5432,
}

module.exports = credentials; 

