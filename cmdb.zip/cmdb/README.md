# csv_node_postgres
Author: Eduard Karesli (ed.karesli@gmail.com)

This is a sample application for processing CSV files using Node.js and storing data in a PostgreSQL database.

